#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "AnimeLegendsGameMode.generated.h"

UCLASS()
class ANIMELEGENDS_API AAnimeLegendsGameMode : public AGameModeBase
{
    GENERATED_BODY()

public:
    AAnimeLegendsGameMode();
};
