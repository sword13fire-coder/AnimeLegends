#include "AnimeLegendsGameMode.h"
#include "GameFramework/DefaultPawn.h"

AAnimeLegendsGameMode::AAnimeLegendsGameMode()
{
    // Temporary starter pawn. Replace with the custom hero character
    // when the first playable character is added.
    DefaultPawnClass = ADefaultPawn::StaticClass();
}
