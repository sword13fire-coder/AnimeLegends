#include "AnimeLegends.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE(FDefaultGameModuleImpl, AnimeLegends, "AnimeLegends");
