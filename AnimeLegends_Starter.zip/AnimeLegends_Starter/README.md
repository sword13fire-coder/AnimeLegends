# AnimeLegends

A starter Unreal Engine 5.8 C++ project for a 3D anime-inspired open-world adventure targeting Android and Windows.

## Current starter contents
- Unreal project descriptor
- C++ runtime module
- Basic game mode
- Temporary default pawn for initial testing
- Initial project configuration

## Important
This is a source starter scaffold, not a finished game and not an APK/EXE.
It still needs to be opened and built with Unreal Engine 5.8 in a compatible build environment.
No third-party anime characters, models, sounds, or copyrighted assets are included.

## Next development steps
1. Create the first original playable character.
2. Add a third-person camera and movement.
3. Add touch controls for Android.
4. Create a small test island.
5. Add basic interaction and combat systems.
6. Configure Android and Windows packaging.
